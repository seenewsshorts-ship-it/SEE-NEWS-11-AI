package com.seenews11.ainewsmaker

import android.net.Uri
import android.os.Bundle
import android.util.Base64
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

private val http = OkHttpClient.Builder()
    .connectTimeout(20, TimeUnit.SECONDS)
    .readTimeout(180, TimeUnit.SECONDS)
    .build()

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ChatNewsMaker() }
    }
}

private data class ChatMessage(val fromUser: Boolean, val text: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatNewsMaker() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var prompt by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf("script") }
    var location by remember { mutableStateOf("दानापुर, पटना") }
    var imageBase64 by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("खबर लिखें या नीचे से कोई काम चुनें।") }
    val messages = remember {
        mutableStateListOf(
            ChatMessage(false, "नमस्कार! मैं SEE NEWS 11 AI News Maker हूँ।\\n\\nआप मुझे खबर दें और कहें—हेडिंग लिखो, एंकर स्क्रिप्ट बनाओ या न्यूज़ थंबनेल बनाओ।")
        )
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.openInputStream(uri)?.use { input ->
                    imageBase64 = Base64.encodeToString(input.readBytes(), Base64.NO_WRAP)
                    status = "फोटो जुड़ गई। अब “फोटो से खबर” भेजें।"
                }
            } catch (e: Exception) { status = "फोटो नहीं पढ़ी जा सकी: ${e.localizedMessage}" }
        }
    }

    fun sendMessage(selectedMode: String) {
        val userText = prompt.trim()
        if (userText.isBlank() && imageBase64 == null) {
            status = "पहले खबर लिखें या प्रेस नोट की फोटो चुनें।"
            return
        }
        mode = selectedMode
        val displayText = when(selectedMode) {
            "headings" -> "हेडिंग लिखो: $userText"
            "script" -> "न्यूज़ स्क्रिप्ट बनाओ: $userText"
            "thumbnail" -> "न्यूज़ थंबनेल बनाओ: $userText"
            else -> "फोटो से खबर बनाओ"
        }
        messages.add(ChatMessage(true, displayText))
        prompt = ""
        busy = true
        status = "AI जवाब तैयार कर रहा है…"
        scope.launch {
            val result = withContext(Dispatchers.IO) {
                try {
                    val path: String
                    val payload: JSONObject
                    when {
                        selectedMode == "photo" && imageBase64 != null -> {
                            path = "photo-to-news"
                            payload = JSONObject().put("imageBase64", imageBase64)
                        }
                        selectedMode == "thumbnail" -> {
                            path = "generate-thumbnail"
                            payload = JSONObject().put("title", userText.ifBlank { "बड़ी खबर" })
                                .put("subtitle", "SEE NEWS 11 हिंदी न्यूज़ थंबनेल")
                                .put("imageBase64", imageBase64 ?: "")
                        }
                        else -> {
                            path = "generate-text"
                            val task = if (selectedMode == "headings") "headings" else "script"
                            payload = JSONObject().put("task", task).put("topic", userText)
                                .put("location", location).put("facts", userText)
                                .put("duration", "1 मिनट")
                        }
                    }
                    val body = payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
                    val req = Request.Builder().url(ApiConfig.BASE_URL + path).post(body).build()
                    http.newCall(req).execute().use { res ->
                        val raw = res.body?.string().orEmpty()
                        if (!res.isSuccessful) throw Exception("Server ${res.code}: $raw")
                        val obj = JSONObject(raw)
                        if (obj.has("error")) throw Exception(obj.optString("error"))
                        if (selectedMode == "thumbnail") {
                            "AI थंबनेल बैकग्राउंड तैयार हो गया है।\\n\\nइस संस्करण में थंबनेल को चैट में दिखाने और PNG सेव करने की सुविधा अगली build में जोड़नी होगी।"
                        } else obj.optString("text", "जवाब नहीं मिला।")
                    }
                } catch (e: Exception) {
                    "कनेक्शन/AI में समस्या: ${e.message}\\n\\nसर्वर चालू है और API key सेट है, यह जाँचें।"
                }
            }
            busy = false
            messages.add(ChatMessage(false, result))
            status = "प्रकाशित करने से पहले खबर के तथ्य जाँचें।"
            if (selectedMode == "photo") imageBase64 = null
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFFFFD32A), secondary = Color(0xFFE5222B),
        background = Color(0xFF101116), surface = Color(0xFF1B1D25),
        onPrimary = Color.Black, onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Color(0xFF101116),
            topBar = {
                Row(
                    Modifier.fillMaxWidth().background(Color(0xFF191A20)).padding(horizontal = 16.dp, vertical = 13.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(38.dp).background(Color(0xFFB00008), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                        Text("11", color = Color.White, fontWeight = FontWeight.Black)
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("SEE NEWS 11", fontWeight = FontWeight.Bold, fontSize = 19.sp)
                        Text("AI News Maker", fontSize = 12.sp, color = Color.LightGray)
                    }
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color(0xFFFFD32A))
                }
            },
            bottomBar = {
                Column(Modifier.fillMaxWidth().background(Color(0xFF101116)).padding(horizontal = 12.dp, vertical = 8.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
                        FilterChip(selected = mode == "headings", onClick = { mode = "headings" }, label = { Text("हेडिंग") })
                        FilterChip(selected = mode == "script", onClick = { mode = "script" }, label = { Text("स्क्रिप्ट") })
                        FilterChip(selected = mode == "thumbnail", onClick = { mode = "thumbnail" }, label = { Text("थंबनेल") })
                    }
                    Row(
                        Modifier.fillMaxWidth().background(Color(0xFF20222A), RoundedCornerShape(24.dp)).padding(8.dp),
                        verticalAlignment = Alignment.Bottom
                    ) {
                        IconButton(onClick = { picker.launch("image/*") }) {
                            Icon(Icons.Default.AddPhotoAlternate, contentDescription = "फोटो चुनें", tint = Color.LightGray)
                        }
                        Column(Modifier.weight(1f).padding(vertical = 8.dp)) {
                            BasicTextField(
                                value = prompt, onValueChange = { prompt = it },
                                modifier = Modifier.fillMaxWidth(),
                                textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 15.sp),
                                cursorBrush = androidx.compose.ui.graphics.SolidColor(Color(0xFFFFD32A)),
                                decorationBox = { inner ->
                                    if (prompt.isEmpty()) Text(
                                        if (imageBase64 != null) "फोटो जुड़ी है… खबर के लिए निर्देश लिखें" else "अपनी खबर यहाँ लिखें…",
                                        color = Color.Gray, fontSize = 14.sp
                                    )
                                    inner()
                                }
                            )
                            if (imageBase64 != null) Text("📎 प्रेस नोट की फोटो जुड़ी है", color = Color(0xFFFFD32A), fontSize = 11.sp)
                        }
                        IconButton(
                            onClick = { sendMessage(if (imageBase64 != null && prompt.isBlank()) "photo" else mode) },
                            enabled = !busy
                        ) {
                            Icon(Icons.Default.ArrowUpward, contentDescription = "भेजें",
                                tint = Color.Black, modifier = Modifier.background(Color(0xFFFFD32A), RoundedCornerShape(50)).padding(7.dp))
                        }
                    }
                    if (imageBase64 != null) {
                        TextButton(onClick = { sendMessage("photo") }, enabled = !busy) { Text("फोटो से खबर बनाएं") }
                    }
                    Text(status, fontSize = 11.sp, color = Color.Gray, modifier = Modifier.padding(start = 8.dp, top = 4.dp))
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.padding(padding).fillMaxSize().padding(horizontal = 12.dp),
                contentPadding = PaddingValues(top = 14.dp, bottom = 14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                itemsIndexed(messages) { _, msg ->
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = if (msg.fromUser) Arrangement.End else Arrangement.Start
                    ) {
                        Column(
                            Modifier.widthIn(max = 330.dp)
                                .background(
                                    if (msg.fromUser) Color(0xFF30323B) else Color(0xFF1B1D25),
                                    RoundedCornerShape(18.dp)
                                ).padding(14.dp)
                        ) {
                            if (!msg.fromUser) Text("SEE NEWS 11 AI", color = Color(0xFFFFD32A), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(4.dp))
                            Text(msg.text, color = Color.White, fontSize = 15.sp, lineHeight = 22.sp)
                        }
                    }
                }
                if (busy) item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Color(0xFFFFD32A))
                        Spacer(Modifier.width(10.dp)); Text("जवाब तैयार हो रहा है…", color = Color.LightGray, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}
