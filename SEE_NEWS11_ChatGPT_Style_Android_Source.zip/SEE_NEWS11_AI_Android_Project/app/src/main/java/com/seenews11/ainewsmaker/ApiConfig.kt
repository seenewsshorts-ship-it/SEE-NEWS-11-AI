package com.seenews11.ainewsmaker

object ApiConfig {
    // Change to your hosted HTTPS backend, or your computer's LAN IP for local testing.
    const val BASE_URL = "http://10.0.2.2:3000/"
}
