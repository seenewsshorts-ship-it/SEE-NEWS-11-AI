import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import OpenAI from "openai";

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json({ limit: "18mb" }));

if (!process.env.OPENAI_API_KEY) {
  console.warn("OPENAI_API_KEY is missing. Add it to backend/.env");
}
const ai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const textModel = process.env.TEXT_MODEL || "gpt-4o-mini";
const imageModel = process.env.IMAGE_MODEL || "gpt-image-1";

app.get("/health", (_req, res) => res.json({ ok: true, service: "SEE NEWS 11 AI backend" }));

app.post("/generate-text", async (req, res) => {
  try {
    const { task, topic = "", location = "", facts = "", duration = "1 मिनट" } = req.body || {};
    const system = `आप SEE NEWS 11 के हिंदी न्यूज़ डेस्क सहायक हैं। साफ, स्वाभाविक, एंकर-पढ़ने योग्य हिंदी लिखें। केवल दिए गए तथ्यों पर आधारित रहें। कोई नाम, तारीख, गिरफ्तारी, आरोप, संख्या, उद्धरण या निष्कर्ष न गढ़ें। आरोप को आरोप के रूप में ही लिखें और जहाँ जरूरी हो आधिकारिक पुष्टि लंबित होने का उल्लेख करें।`;
    let prompt;
    if (task === "headings") {
      prompt = `नीचे की खबर के लिए 8 अलग-अलग हिंदी हेडिंग दें। 3 मुख्य हेडिंग, 3 छोटी थंबनेल हेडिंग और 2 सोशल मीडिया हेडिंग दें। सनसनीखेज झूठा दावा न करें।\nविषय: ${topic}\nस्थान: ${location}\nतथ्य: ${facts}`;
    } else {
      prompt = `${duration} की हिंदी टीवी न्यूज़ एंकर स्क्रिप्ट लिखें। शुरुआत में अभिवादन और SEE NEWS 11 का नाम हो, फिर खबर, संदर्भ और संक्षिप्त समापन। केवल दिए गए तथ्य इस्तेमाल करें।\nविषय: ${topic}\nस्थान: ${location}\nतथ्य/प्रेस नोट: ${facts}`;
    }
    const completion = await ai.chat.completions.create({
      model: textModel,
      messages: [{ role: "system", content: system }, { role: "user", content: prompt }],
      temperature: 0.6
    });
    res.json({ text: completion.choices?.[0]?.message?.content || "कोई आउटपुट नहीं मिला।" });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: e.message || "AI request failed" });
  }
});

app.post("/photo-to-news", async (req, res) => {
  try {
    const { imageBase64 } = req.body || {};
    if (!imageBase64) return res.status(400).json({ error: "imageBase64 required" });
    const dataUrl = `data:image/jpeg;base64,${imageBase64}`;
    const completion = await ai.chat.completions.create({
      model: textModel,
      messages: [
        { role: "system", content: "आप हिंदी न्यूज़ डेस्क सहायक हैं। तस्वीर में दिख रहे प्रेस नोट/दस्तावेज़ को पढ़ें और केवल पढ़े जा सकने वाले तथ्य निकालें। अस्पष्ट हिस्सों को अस्पष्ट बताएं, कोई तथ्य न गढ़ें। फिर हिंदी में संक्षिप्त खबर का ड्राफ्ट बनाएं।" },
        { role: "user", content: [
          { type: "text", text: "इस प्रेस नोट/खबर की तस्वीर पढ़कर शीर्षक और तथ्य-सावधान हिंदी न्यूज़ ड्राफ्ट बनाएं।" },
          { type: "image_url", image_url: { url: dataUrl, detail: "high" } }
        ]}
      ],
      temperature: 0.2
    });
    const text = completion.choices?.[0]?.message?.content || "फोटो से टेक्स्ट नहीं पढ़ा जा सका।";
    res.json({ text, suggestedTopic: "प्रेस नोट से तैयार खबर" });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: e.message || "Photo analysis failed" });
  }
});

app.post("/generate-thumbnail", async (req, res) => {
  try {
    const { title = "बड़ी खबर", subtitle = "", imageBase64 = "" } = req.body || {};
    // Use image generation for a background/thumbnail concept. Hindi text should be added
    // in a later client-side compositing pass for reliable spelling.
    const prompt = `Create a professional 16:9 Indian Hindi TV news thumbnail BACKGROUND for SEE NEWS 11. Topic: ${title}. Supporting context: ${subtitle}. High contrast red, black and yellow breaking-news palette, cinematic newsroom lighting, clean composition, leave large clear empty space in the center for Hindi headline overlay. No logos, no readable text, no watermarks. Do not depict specific real people unless supplied by the user.`;
    const result = await ai.images.generate({
      model: imageModel,
      prompt,
      size: "1536x1024"
    });
    const b64 = result.data?.[0]?.b64_json;
    if (!b64) return res.status(502).json({ error: "Image API returned no image" });
    res.json({ imageBase64: b64, mimeType: "image/png", text: "AI thumbnail background तैयार है। हिंदी टेक्स्ट overlay अगली build में जोड़ा जा सकता है।" });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: e.message || "Thumbnail generation failed" });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, "0.0.0.0", () => console.log(`SEE NEWS 11 backend listening on ${port}`));
