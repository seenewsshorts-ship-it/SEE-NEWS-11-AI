# SEE NEWS 11 AI News Maker — Android source project

यह Android Studio के लिए source project है, सीधे install होने वाला APK नहीं।

## सुविधाएँ
- ChatGPT-जैसी चैट स्क्रीन में AI से हिंदी headline ideas और anchor script
- प्रेस नोट का टेक्स्ट डालकर खबर बनाना
- फोटो चुनकर vision-capable AI से जानकारी का ड्राफ्ट बनवाना
- AI thumbnail background generation (thumbnail preview/save UI अभी अधूरा है)
- API key Android ऐप में नहीं रखी जाती; backend server पर रखी जाती है

## जरूरी सेटअप
1. कंप्यूटर पर Android Studio और Node.js 20+ इंस्टॉल करें।
2. `backend` फ़ोल्डर में:
   - `npm install`
   - `.env.example` को `.env` नाम दें
   - `.env` में अपनी API key रखें
   - `npm start`
3. Android फोन और backend एक ही Wi-Fi पर हों तो `app/src/main/java/com/seenews11/ainnewsmaker/ApiConfig.kt` में `BASE_URL` को अपने कंप्यूटर के LAN IP और पोर्ट 3000 से बदलें, जैसे `http://192.168.1.5:3000/`.
   - Production में HTTPS वाला hosted backend इस्तेमाल करें।
4. Android Studio में इस फ़ोल्डर को खोलें, Gradle sync करें और Run दबाएँ।
5. APK के लिए: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## सुरक्षा
- API key को Android app में कभी न डालें।
- Production deployment में HTTPS, authentication, rate limiting और usage limits जोड़ें।
- प्रेस नोट/फोटो से बना कंटेंट ड्राफ्ट है; नाम, आरोप, तारीख, बरामदगी और अन्य तथ्यों को प्रकाशित करने से पहले सत्यापित करें।
- AI thumbnail generation उपलब्धता और API account/model permissions पर निर्भर करेगी।

## सीमाएँ
इस पैकेज में source code है, compiled/sign किए हुए APK का दावा नहीं है। इस execution environment में Android SDK/Gradle build tool उपलब्ध नहीं मिला, इसलिए APK compile नहीं किया गया।
